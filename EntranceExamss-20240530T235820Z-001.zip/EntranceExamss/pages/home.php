<div class="app-main__outer">
    <div id="refreshData">
        <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                    <img src="sec_logo.jpg" alt="sec" width="50" height="50">
                    </div>
                        <div>AUTOMATED QUIZ REVIEWER SYSTEM
                        <div class="page-title-subheading">Keep in mind: PLEASE READ QUESTIONS CAREFULLY AND BECOME NUMBER 1
                    </div>
                </div>                  
            </div>      
            </div>
        </div>
    </div>  
</div>
