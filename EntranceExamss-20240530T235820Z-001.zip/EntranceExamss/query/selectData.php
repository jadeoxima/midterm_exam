<?php 
$exmneId = $_SESSION['examineeSession']['exmne_id'];

// Select Data sa nilogin nga examinee
$selExmneeData = $conn->query("SELECT * FROM examinee_tbl WHERE exmne_id='$exmneId' ")->fetch(PDO::FETCH_ASSOC);



        
// Select ang tanang exam nga ni login 
$selExam = $conn->query("SELECT * FROM exam_tbl ORDER BY ex_id DESC ");


//

 ?>