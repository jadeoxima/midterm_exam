<!-- Add the required CSS styles -->
<style>
     .pass {
        color: green;
    }
    .enhancement {
        color: red;
    }
    .text-container {
    display: flex;
    align-items: center;
}

.logo {
    width: 100px; /* Adjust the width as needed */
    height: auto; /* Maintain aspect ratio */
    margin-right: 10px; /* Reduced margin to make it closer to the text header */
}

.content {
    flex: 1;
}

    .main-card {
        margin-top: 20px; /* Add some top margin to create space before the table */
    }
   

.left-content {
    text-align: left;
    margin-left: 10px;
}

.right-content {
    text-align: left;
}

.kit {
    text-align: right;
}

.jade {
    text-align: left;
    font-weight: bold;

    
}


/* Style the input fields to fit the width of the container */
   
    /* Additional CSS styles can be added here if needed */
</style>

<?php 
include("../../../conn.php");

// Assuming you have a user authentication mechanism in place and the user ID is available here.
$id = isset($_GET['id']) ? $_GET['id'] : ''; // You should replace this line with your authentication mechanism.

// Fetch the examinee details for the currently logged-in user
$selExmne = $conn->query("SELECT * FROM examinee_tbl WHERE exmne_id='$id' ")->fetch(PDO::FETCH_ASSOC);
?>

<div class="app-main__outer">
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
                    EXAMINEE RESULT
                </div>
            </div>
        </div>       
        <section clascs=""> 

        <div class="col-md-12" align="center">
            <div class="main-card mb-3 card" align="center">
                <div class="card-header"> 
                    <legend>
                        <i class="facebox-header"><i class="edit large icon"></i>&nbsp;View Result of ( <?php echo strtoupper($selExmne['exmne_fullname']); ?> )</i>
                    </legend>
                </div>
                <div id="print-content">
                <div class="text-container">
    <img class="logo" src="sec_logo.jpg" alt="Logo">
    <div class="content">
        <h3 style="font-weight: bold;">SURIGAO EDUCATION CENTER</h3>
        <p>Km.2,8400, Surigao,City , Phillippines</p>
    </div>
</div>
<section class="sim">
    <h3>Summary Of result</h3>
</section>

<section class="jade">
    <p>Name:<?php echo $selExmne['exmne_fullname']; ?></p>
    <p>Course:<?php echo $selExmne['exmne_program']; ?></p>
    <p>Date <?php echo date("M j, Y", strtotime($selExmne['exmne_date'])); ?></p>


</section>
                    <!-- Your table content goes here -->
                    <table class="align-middle mb-0 table table-borderless table-striped table-hover" id="tableList">
                    <thead>
                            <tr>
                            <th class="text-left">Exam Name</th>
                                <th>Scores</th>
                                <th>Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            // Fetch all the exams attempted by the currently logged-in user
                            $selExams = $conn->query("SELECT * FROM exam_attempt WHERE exmne_id='$id' ORDER BY examat_id DESC");
                            if ($selExams->rowCount() > 0) {
                                $englishScore = 0; // Initialize a variable to hold the total English score
                                while ($examAttemptRow = $selExams->fetch(PDO::FETCH_ASSOC)) {
                                    $examId = $examAttemptRow['exam_id'];
                                    $selExam = $conn->query("SELECT * FROM exam_tbl WHERE ex_id='$examId' ")->fetch(PDO::FETCH_ASSOC);
                                    $examTitle = $selExam['ex_title'];
                                    $questionLimit = $selExam['ex_questlimit_display'];

                                    $selScore = $conn->query("SELECT * FROM exam_question_tbl eqt INNER JOIN exam_answers ea ON eqt.eqt_id = ea.quest_id AND eqt.exam_answer = ea.exans_answer  WHERE ea.axmne_id='$id' AND ea.exam_id='$examId' AND ea.exans_status='new' ");
                                    $score = $selScore->rowCount();
                                    $percentage = ($score / $questionLimit) * 100;
                                    $remarks = ($percentage >= 50) ? "Pass" : "For Enhancement";
                                    
                                    // Check if the exam title contains "English" and accumulate the score
                                    if (stripos($examTitle, 'English') !== false) {
                                        $englishScore += $score;
                                    } else {
                                        // Determine the CSS class based on the remarks
                                        $remarksClass = ($remarks === "Pass") ? "pass" : "enhancement";
                            ?>
                            <tr>
                                <td><?php echo $examTitle; ?></td>
                                <td>
                                    <span><?php echo $score; ?></span> / <?php echo $questionLimit; ?>
                                </td>
                                <td class="<?php echo $remarksClass; ?>">
                                    <span><?php echo $remarks; ?></span>
                                </td>
                            </tr>
                            <?php
                                    }
                                }

                                // Output the total English score
                                if ($englishScore > 0) {
                                    // Determine the CSS class based on the remarks
                                    $englishRemarksClass = ($englishScore >= 60) ? "pass" : "enhancement";
                            ?>
                            <tr>
    <td>English</td>
    <td>
        <span><?php echo $englishScore; ?></span> / <?php echo $questionLimit; ?>
    </td>
    <td class="<?php echo $englishRemarksClass; ?>">
        <span><?php echo ($englishScore >= 60) ? "Pass" : "For Enhancement"; ?></span>
    </td>
</tr>

                            <?php
                                }
                            } else {
                            ?>
                            
                            <tr>
                                <td colspan="2">
                                    <h3 class="p-3">No Exam Found</h3>
                                </td>
                            </tr>
                            <?php
                            }
                            ?>
                          <th>
        

                        </tbody>
                        
                    </table>    
                    <section class="kit">
           <p> Examiner___________________
                        </p>
                </div>
            </div>
            
            <!-- Add the print functionality using JavaScript -->
            <button class="btn btn-primary" onclick="printContent()"><i class="fa fa-print"></i> Print</button>
        </div>
    </div>
    <!-- Your table content goes here -->
    
    </div>
    <script>
    function printContent() {
        var printDiv = document.getElementById("print-content");
        var printWindow = window.open('', '', 'height=500,width=800');
        printWindow.document.write('<html><head><title>Print</title></head><body>');
        printWindow.document.write(printDiv.innerHTML);
        printWindow.document.write('<style>' + getStyles() + '</style>'); // Add the required CSS styles
        printWindow.document.write('</head><body>');
        printWindow.document.write('<div class="main-card mb-3 card" align="center">');
        printWindow.document.write('<div class="card-header">');
        printWindow.document.write('</div>');
        
       
        printWindow.print();
    }


    function getStyles() {
        // Function to retrieve the required CSS styles
        return `
            /* Paste your required CSS styles here */
            .pass {
        text-align: center; /* Center the text within the table cells */
        margin-right: -12px;    }
    
    
        .text-container {
        display: flex;
        align-items: center;
        justify-content: center; /* Add this line to center the content horizontally */
    }

    .logo {
        width: 100px; /* Adjust the width as needed */
        height: auto; /* Maintain aspect ratio */
        margin-right: 10px; /* Reduced margin to make it closer to the text header */
    }


.main-card {
    margin-top: 20px;
}

.text-left {
    text-align: left;
}

.kit {
    text-align: right;
}


.jade {
    display: inline;
    margin-bottom-15px;
    align-items: left;
    font-weight: bold;

}

.left-content {
    text-align: left;
    margin-left: 10px;
}

.sim {
    text-align: center;
    margin-top:20px;
}

   


        `;
    }

    
</script>
</div>
