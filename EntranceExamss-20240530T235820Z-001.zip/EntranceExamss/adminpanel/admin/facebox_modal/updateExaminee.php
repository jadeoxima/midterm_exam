
<?php 
  include("../../../conn.php");
  $id = $_GET['id'];
 
  $selExmne = $conn->query("SELECT * FROM examinee_tbl WHERE exmne_id='$id' ")->fetch(PDO::FETCH_ASSOC);

 ?>

<fieldset style="width:543px;" >
	<legend><i class="facebox-header"><i class="edit large icon"></i>&nbsp;Update <b>( <?php echo strtoupper($selExmne['exmne_fullname']); ?> )</b></i></legend>
  <div class="col-md-12 mt-4">
<form method="post" id="updateExamineeFrm">
     <div class="form-group">
        <legend>Include (Last Name, First Name, Middle Name and Suffix if necessary)</legend>
        <input type="hidden" name="exmne_id" value="<?php echo $id; ?>">
        <input type="" name="exFullname" class="form-control" required="" value="<?php echo $selExmne['exmne_fullname']; ?>" >
     </div>
     <div class="form-group">
        <legend>Age</legend>
        <input type="number" name="exAge" class="form-control" required="" value="<?php echo $selExmne["exmne_age"] ?>"/>
     </div>
     <div class="form-group">
        <legend>Gender</legend>
        <select class="form-control" name="exGender">
          <option value="<?php echo $selExmne['exmne_gender']; ?>"><?php echo $selExmne['exmne_gender']; ?></option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
     </div>

     <div class="form-group">
        <legend>Date</legend>
        <input type="date" name="exDate" class="form-control" required="" value="<?php echo date('Y-m-d',strtotime($selExmne["exmne_date"])) ?>"/>
     </div>
     
     <div class="form-group">
        <legend>OR Number</legend>
        <input type="number" name="exORNumber" class="form-control" required="" value="<?php echo $selExmne["exmne_ornumber"] ?>"/>
     </div>
     <div class="form-group">
        <legend>Department</legend>
        <?php 
            $exmneCourse = $selExmne['exmne_course'];
            $selCourse = $conn->query("SELECT * FROM course_tbl WHERE cou_id='$exmneCourse' ")->fetch(PDO::FETCH_ASSOC);
         ?>
         <select class="form-control" name="exCourse">
           <option value="<?php echo $exmneCourse; ?>"><?php echo $selCourse['cou_name']; ?></option>
           <?php 
             $selCourse = $conn->query("SELECT * FROM course_tbl WHERE cou_id!='$exmneCourse' ");
             while ($selCourseRow = $selCourse->fetch(PDO::FETCH_ASSOC)) { ?>
              <option value="<?php echo $selCourseRow['cou_id']; ?>"><?php echo $selCourseRow['cou_name']; ?></option>
            <?php  }
            ?>
         </select>
     </div>

     <div class="form-group">
        <legend>Program</legend>
        <select type="" name="exProgram" class="form-control" required="" value="<?php echo $selExmne['exmne_program']; ?>">
        <option value="<?php echo $selExmne['exmne_program']; ?>"><?php echo $selExmne['exmne_program']; ?></option>
              <option value="BS Civil Engineering">BS Civil Engineering</option>
              <option value="BS Electrical Engineering">BS Electrical Engineering</option>
              <option value="BS Electronics Engineering">BS Electronics Engineering</option>
              <option value="BS Mechanical Engineering">BS Mechanical Engineering</option>
              <option value="BS Architecture">BS Architecture</option>
              <option value="BS Maritime Transportation">BS Maritime Transportation</option>
              <option value="BS Nursing">BS Nursing</option>
              <option value="BS Radiologic Technology">BS Radiologic Technology</option>
              <option value="BS Midwifery">BS Midwifery</option>
              <option value="BS Accountancy">BS Accountancy</option>
              <option value="BS Hospitality Management">BS Hospitality Management</option>
              <option value="BS Business Administration (Major in Marketing Management)">BS Business Administration (Major in Marketing Management)</option>
              <option value="BS Business Administration (Major in Human Resources Management)">BS Business Administration (Major in Human Resources Management)</option>
              <option value="BS Business Administration (Major in Financial Management)">BS Business Administration (Major in Financial Management)</option>
              <option value="BS Information Technology">BS Information Technology</option>
              <option value="Bachelor of Elementary Education">Bachelor of Elementary Education</option>
              <option value="Bachelor of Secondary Education (Major in Science)">Bachelor of Secondary Education (Major in Science)</option>
              <option value="Bachelor of Secondary Education (Major in Mathematics)">Bachelor of Secondary Education (Major in Mathematics)</option>   
      </select>
      </div>


     <div class="form-group">
        <legend>Email</legend>
        <input type="" name="exEmail" class="form-control" required="" value="<?php echo $selExmne['exmne_email']; ?>" >
     </div>

     <div class="form-group">
        <legend>Password</legend>
        <input type="" name="exPass" class="form-control" required="" value="<?php echo $selExmne['exmne_password']; ?>" >
     </div>

     <div class="form-group">
        <legend>Status</legend>
        <input type="hidden" name="course_id" value="<?php echo $id; ?>">
        <input type="" name="newCourseName" class="form-control" required="" value="<?php echo $selExmne['exmne_status']; ?>" >
     </div>
  <div class="form-group" align="right">
    <button type="submit" class="btn btn-sm btn-primary">Update Now</button>
  </div>
</form>
  </div>
</fieldset>







