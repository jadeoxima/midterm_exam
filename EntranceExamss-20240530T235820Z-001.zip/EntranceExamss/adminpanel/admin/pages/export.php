<?php
header("Content-Type: application/xls");
header("Content-Disposition: attachment; filename=Program_list.xls");
header("Pragma: no-cache");
header("Expires: 0");

require_once '../conn.php';

$output = "";

$output .= "
    <table>
        <tr>
            <th>Name</th>
            <th>OR Number</th>
            <th>Program</th>
            <th>Status</th>
        </tr>
        <tbody>
";

$filter = isset($_GET['exmne_program']) ? $_GET['exmne_program'] : '';

$query = $conn->prepare("SELECT * FROM examinee_tbl WHERE exmne_program LIKE :filter");
$query->bindValue(':filter', '%' . $filter . '%');
$query->execute();

if ($query->rowCount() > 0) {
    while ($fetch = $query->fetch()) {
        $output .= "
            <tr>
                <td>".$fetch['exmne_fullname']."</td>
                <td>".$fetch['exmne_ornumber']."</td>
                <td>".$fetch['exmne_program']."</td>
                <td>".$fetch['exmne_status']."</td>
            </tr>
        ";
    }
} else {
    $output .= "
        <tr>
            <td colspan='4'>No results found.</td>
        </tr>
    ";
}

$output .= "
        </tbody>
    </table>
";

echo $output;
exit;
?>
