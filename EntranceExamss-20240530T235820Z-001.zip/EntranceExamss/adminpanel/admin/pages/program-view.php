<?php
include("../../conn.php");

$filter = $_GET['exmne_program'];


    

?>

<link rel="stylesheet" type="text/css" href="css/mycss.css">
<div class="app-main__outer">
    <div class="app-main__inner">
        <div class="app-page-title">
            <div class="page-title-wrapper">
                <div class="page-title-heading">
            </div>
            <div class="col-md-12">
                <div class="main-card mb-3 card">
                    <div class="card-header">
                        <h5 class="card-title">Student List</h5>
                    </div>
                    <div class="float-right" align="center">
                       <a href="pages/export.php?exmne_program=<?php echo $filter; ?>" class="btn btn-success"><i class="fa fa-download"></i>   Export to Excel </a>
                       
                    </div>
                    <div class="table-responsive">
                        <table class="align-middle mb-0 table table-borderless table-striped table-hover" id="tableList">
                            <thead>
                                <tr>
                                    <th>Fullname</th>
                                    <th>OR Number</th>
                                    <th>Program</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if (isset($_GET['exmne_program']) && !empty($_GET['exmne_program'])) {
                                    $servername = "localhost";
                                    $username = "root";
                                    $password = "";
                                    $dbname = "ees_db";

                                    try {
                                        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                                        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                                        $stmt = $conn->prepare("SELECT * FROM examinee_tbl WHERE exmne_program LIKE :filter");
                                        $stmt->bindValue(':filter', '%' . $filter . '%');
                                        $stmt->execute();

                                        if ($stmt->rowCount() > 0) {
                                            while ($selExmneRow = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                ?>
                                                <tr>
                                                    <td><?php echo $selExmneRow['exmne_fullname']; ?></td>
                                                    <td><?php echo $selExmneRow['exmne_ornumber']; ?></td>
                                                    <td><?php echo $selExmneRow['exmne_program']; ?></td>
                                                    <td><?php echo $selExmneRow['exmne_status']; ?></td>
                                                </tr>
                                                <?php
                                            }
                                        } else {
                                            echo "<tr><td colspan='4'>No results found.</td></tr>";
                                        }
                                    } catch (PDOException $e) {
                                        echo "<tr><td colspan='4'>Database connection failed: " . $e->getMessage() . "</td></tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='4'>No 'exmne_program' parameter provided.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
