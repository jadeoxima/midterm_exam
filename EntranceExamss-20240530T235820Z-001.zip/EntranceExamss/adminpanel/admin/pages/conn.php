<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "ees_db";


try {
    $conn = new PDO("mysql:host={$host};dbname={$db};",$user,$pass);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
