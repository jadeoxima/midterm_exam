<?php
include("conn.php")
?>
<!DOCTYPE html>
<html>
<head>
    <title>Exam Results</title>
    <!-- Add the required CSS styles -->
    <style>
        .pass {
            color: green;
        }
        .enhancement {
            color: red;
        }
        /* Additional CSS styles can be added here if needed */
    </style>
</head>
<body>
    <div class="app-main__outer">
        <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                        EXAMINEE RESULT
                    </div>
                </div>
            </div>

            <?php
            include("conn.php");

            // Assuming you have a user authentication mechanism in place and the user ID is available here.
            $id = isset($_GET['id']) ? $_GET['id'] : ''; // You should replace this line with your authentication mechanism.

            // Fetch the examinee details for the currently logged-in user
            $selExmne = $conn->query("SELECT * FROM examinee_tbl WHERE exmne_id='$id' ")->fetch(PDO::FETCH_ASSOC);
            ?>

            <div class="col-md-12" align="center">
                <div class="main-card mb-3 card" align="center">
                    <div class="card-header"> 
                        <legend>
                        </legend>
                    </div>
                    <div class="table-responsive">
                        <div class="logo-container">
                            <img class="logo" src="logo.png" alt="Logo">
                            <div class="text-container">
                                <h6>SURIGAO EDUCATION CENTER</h6>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elie.</p>
                            </div>
                        </div>
                        <table class="align-middle mb-0 table table-borderless table-striped table-hover" id="tableList">
                            <thead>
                                <tr>
                                    <th>Exam Name</th>
                                    <th>Scores</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                // Fetch all the exams attempted by the currently logged-in user
                                $selExams = $conn->query("SELECT * FROM exam_attempt WHERE exmne_id='$id' ORDER BY examat_id DESC");
                                if ($selExams->rowCount() > 0) {
                                    $englishScore = 0; // Initialize a variable to hold the total English score
                                    while ($examAttemptRow = $selExams->fetch(PDO::FETCH_ASSOC)) {
                                        $examId = $examAttemptRow['exam_id'];
                                        $selExam = $conn->query("SELECT * FROM exam_tbl WHERE ex_id='$examId' ")->fetch(PDO::FETCH_ASSOC);
                                        $examTitle = $selExam['ex_title'];
                                        $questionLimit = $selExam['ex_questlimit_display'];

                                        $selScore = $conn->query("SELECT * FROM exam_question_tbl eqt INNER JOIN exam_answers ea ON eqt.eqt_id = ea.quest_id AND eqt.exam_answer = ea.exans_answer  WHERE ea.axmne_id='$id' AND ea.exam_id='$examId' AND ea.exans_status='new' ");
                                        $score = $selScore->rowCount();
                                        $percentage = ($score / $questionLimit) * 100;
                                        $remarks = ($percentage >= 60) ? "Pass" : "For Enhancement";

                                        // Check if the exam title contains "English" and accumulate the score
                                        if (stripos($examTitle, 'English') !== false) {
                                            $englishScore += $score;
                                        } else {
                                            // Determine the CSS class based on the remarks
                                            $remarksClass = ($remarks === "Pass") ? "pass" : "enhancement";
                                ?>
                                <tr>
                                    <td><?php echo $examTitle; ?></td>
                                    <td>
                                        <span><?php echo $score; ?></span> / <?php echo $questionLimit; ?>
                                    </td>
                                    <td class="<?php echo $remarksClass; ?>">
                                        <span><?php echo $remarks; ?></span>
                                    </td>
                                </tr>
                                <?php
                                        }
                                    }

                                    // Output the total English score
                                    if ($englishScore > 0) {
                                        // Determine the CSS class based on the remarks
                                        $englishRemarksClass = ($englishScore >= 60) ? "pass" : "enhancement";
                                ?>
                                <tr>
                                    <td>English</td>
                                    <td>
                                        <span><?php echo $englishScore; ?></span>
                                    </td>
                                    <td class="<?php echo $englishRemarksClass; ?>">
                                        <span><?php echo ($englishScore >= 60) ? "Pass" : "For Enhancement"; ?></span>
                                    </td>
                                </tr>
                                <?php
                                    }
                                } else {
                                ?>
                                <tr>
                                    <td colspan="3">
                                        <h3 class="p-3">No Exam Found</h3>
                                    </td>
                                </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- Add the print functionality using JavaScript -->
                <button class="btn btn-primary" onclick="printTable()"><i class="fa fa-print"></i> Print</button>
            </div>
        </div>
    </div>

    <!-- Modal to display the table for printing -->
    <div class="modal fade" id="printModal" tabindex="-1" role="dialog" aria-labelledby="printModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="printModalLabel">Exam Results</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Table to be printed -->
                    <table class="align-middle mb-0 table table-borderless table-striped table-hover" id="printTable">
                        <!-- Table content goes here -->
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="printTable()">Print</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Add the required JavaScript -->
    <script>
        function printTable() {
            // Clone the table containing the exam results
            var tableToPrint = document.getElementById('tableList').cloneNode(true);

            // Create a new window to print the table
            var printWindow = window.open('', '_blank');
            printWindow.document.open();

            // Add the cloned table to the new window's document
            printWindow.document.write('<html><head><title>Exam Results</title>');
            printWindow.document.write('<style>');
            printWindow.document.write(`
                /* Add the required CSS styles for printing */
                .pass {
                    color: green;
                }
                .enhancement {
                    color: red;
                }
                /* Additional CSS styles can be added here if needed */
            `);
            printWindow.document.write('</style>');
            printWindow.document.write('</head><body>');
            printWindow.document.write('<h1>Exam Results</h1>');
            printWindow.document.write(tableToPrint.outerHTML);
            printWindow.document.write('</body></html>');
            printWindow.document.close();

            // Trigger the print dialog
            printWindow.print();
            printWindow.close();
        }
    </script>
</body>
</html>
