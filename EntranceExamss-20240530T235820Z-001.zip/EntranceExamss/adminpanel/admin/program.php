<?php 
session_start();

if(!isset($_SESSION['admin']['adminnakalogin']) == true) header("location:index.php");


 ?>
<?php include("../../conn.php"); ?>
<!-- MAO NI ANG HEADER -->
<?php include("includes/header.php"); ?>      

<!-- UI THEME DIRI -->
<?php include("includes/ui-theme.php"); ?>

<div class="app-main">
<!-- sidebar diri  -->
<?php include("includes/sidebar.php"); ?>

<?php 
  
    
    $id = $_GET['id'];
    
    $selCourse = $conn->query("SELECT * FROM course_tbl WHERE cou_id='$id' ")->fetch(PDO::FETCH_ASSOC);

 ?>
<link rel="stylesheet" type="text/css" href="css/mycss.css">
<div class="app-main__outer">
        <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                    <legend><i class="facebox-header"><i class="edit large icon"></i>&nbsp;View Department Name ( <?php echo strtoupper($selCourse['cou_name']); ?> )</i></legend>
                </div>
            </div>        
         
            <div class="col-md-12">
                <div class="main-card mb-3 card">
                    <div class="card-header">Program List</div>
                    <div class="float-right">
                    
                    </div>
               
                    <div class="table-responsive">
                        <table class="align-middle mb-0 table table-borderless table-striped table-hover" id="tableList">
                            <thead>
                            <tr>
                                
                                <th>Program</th>
                               
                                <th>Action</th>

                            </tr>
                            </thead>
                            <tbody>
                              <?php 
                             

                               $selExmne = $conn->query("SELECT * FROM program_tbl WHERE cou_id ='$id'");
                                if($selExmne->rowCount() > 0)
                                {
                                    while ($selExmneRow = $selExmne->fetch(PDO::FETCH_ASSOC)) { ?>
                                        <tr>
                                    
                                          
                                           
                                           <td><?php echo $selExmneRow['program']; ?></td>
                                           <td><a style="text-decoration: none;" class="btn btn-success btn-sm" href="home.php?page=program-view&exmne_program=<?php echo $selExmneRow['program']; ?>" id="viewCourse">View</a></td>
                
                                        </tr>
                                    <?php }
                                }
                                else
                                { ?>
                                    <tr>
                                      <td colspan="2">
                                        <h3 class="p-3">No Dept. Found</h3>
                                      </td>
                                    </tr>   
                                <?php }
                               ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>       
</div>