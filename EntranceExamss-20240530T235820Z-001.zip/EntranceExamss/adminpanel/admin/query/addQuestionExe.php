<?php
include("../../../conn.php");

extract($_POST);

$selQuest = $conn->prepare("SELECT * FROM exam_question_tbl WHERE exam_id=:examId AND exam_question=:question");
$selQuest->bindParam(':examId', $examId);
$selQuest->bindParam(':question', $question);
$selQuest->execute();

if ($selQuest->rowCount() > 0) {
    $res = array("res" => "exist", "msg" => $question);
} else {
    $imageFileNameWithoutRelative = ""; 

    if ($_FILES["image"]["error"] == UPLOAD_ERR_OK) {
        $targetDir = "../../../uploads/";
        $imageFileName = uniqid() . "_" . $_FILES["image"]["name"];
        $targetFilePath = $targetDir . $imageFileName;

        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
            $imageFileNameWithoutRelative = "../uploads/" . $imageFileName; 
        } else {
            $res = array("res" => "failed", "msg" => "Error uploading image.");
            echo json_encode($res);
            exit; 
        }
    }

    $insQuest = $conn->prepare("INSERT INTO exam_question_tbl (exam_id, exam_question, image, exam_ch1, exam_ch2, exam_ch3, exam_ch4, exam_ch5, exam_answer) VALUES (:examId, :question, :image, :choice_A, :choice_B, :choice_C, :choice_D, :choice_E, :correctAnswer)");

    $insQuest->bindParam(':examId', $examId);
    $insQuest->bindParam(':question', $question);
    $insQuest->bindParam(':image', $imageFileNameWithoutRelative);
    $insQuest->bindParam(':choice_A', $choice_A);
    $insQuest->bindParam(':choice_B', $choice_B);
    $insQuest->bindParam(':choice_C', $choice_C);
    $insQuest->bindParam(':choice_D', $choice_D);
    $insQuest->bindParam(':choice_E', $choice_E);
    $insQuest->bindParam(':correctAnswer', $correctAnswer);

    if ($insQuest->execute()) {
        $res = array("res" => "success", "msg" => $question);
    } else {
        $res = array("res" => "failed");
    }
}

echo json_encode($res);
?>
