<?php 
 include("../../../conn.php");
session_start();

extract($_POST);
function generateUsername($count) {
    return sprintf("SEC-2023-01-%04d", $count);
}

// Initialize or retrieve the current count from the session
$currentCount = $_SESSION['current_count'] ?? 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Increment the count on each submission
    $currentCount++;
    $_SESSION['current_count'] = $currentCount;

    $username = generateUsername($currentCount);
}

$selExamineeFullname = $conn->query("SELECT * FROM examinee_tbl WHERE exmne_fullname='$fullname' ");
$selExamineeEmail = $conn->query("SELECT * FROM examinee_tbl WHERE exmne_email='$username' ");


if($gender == "0")
{
	$res = array("res" => "noGender");
}
else if($course == "0")
{
	$res = array("res" => "noCourse");
}
else if($program == "0")
{
	$res = array("res" => "noProgram");
}
else if($selExamineeFullname->rowCount() > 0)
{
	$res = array("res" => "fullnameExist", "msg" => $fullname);
}
else if($selExamineeEmail->rowCount() > 0)
{
	$res = array("res" => "emailExist", "msg" => $username);
}
else
{
	$insData = $conn->query("INSERT INTO examinee_tbl(exmne_fullname,exmne_age,exmne_course,exmne_ornumber,exmne_gender,exmne_date,exmne_program,exmne_email,exmne_password) VALUES('$fullname','$age','$course','$ornumber','$gender','$date','$program','$username','$username')  ");
	if($insData)
	{
		$res = array("res" => "success", "msg" => $username);
	}
	else
	{
		$res = array("res" => "failed");
	}
}


echo json_encode($res);
 ?>