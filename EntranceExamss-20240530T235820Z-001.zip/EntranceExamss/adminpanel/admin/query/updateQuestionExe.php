<?php
include("../../../conn.php");
extract($_POST);

$question_id = filter_var($question_id, FILTER_SANITIZE_NUMBER_INT);
$question = filter_var($question, FILTER_SANITIZE_STRING);
$exam_ch1 = filter_var($exam_ch1, FILTER_SANITIZE_STRING);
$exam_ch2 = filter_var($exam_ch2, FILTER_SANITIZE_STRING);
$exam_ch3 = filter_var($exam_ch3, FILTER_SANITIZE_STRING);
$exam_ch4 = filter_var($exam_ch4, FILTER_SANITIZE_STRING);
$exam_ch5 = filter_var($exam_ch5, FILTER_SANITIZE_STRING);

$imagePath = "../../../uploads/";


$selCourse = $conn->query("SELECT * FROM exam_question_tbl WHERE eqt_id='$question_id' ")->fetch(PDO::FETCH_ASSOC);

if (isset($_FILES['image']['name']) && !empty($_FILES['image']['name'])) {
    $imageName = $_FILES['image']['name'];
    $imageTmpName = $_FILES['image']['tmp_name'];

    $allowedExtensions = array("jpg", "jpeg", "png", "gif");
    $fileExtension = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));

    if (!in_array($fileExtension, $allowedExtensions)) {
        $res = array("res" => "invalid_image_extension");
        echo json_encode($res);
        exit();
    }

    $uniqueImageName = uniqid() . '.' . $fileExtension;

    $image = $imagePath . $uniqueImageName;

    if (!move_uploaded_file($imageTmpName, $image)) {
        $res = array("res" => "image_upload_failed");
        echo json_encode($res);
        exit();
    }
} else {
    
    $image = $selCourse['image'];
}


$imagePathInDb = str_replace("../../", "", $image);

$updateQuery = "UPDATE exam_question_tbl SET exam_question='$question', image='$imagePathInDb', exam_ch1='$exam_ch1', exam_ch2='$exam_ch2', exam_ch3='$exam_ch3', exam_ch4='$exam_ch4', exam_ch5='$exam_ch5' WHERE eqt_id='$question_id' ";

if ($conn->query($updateQuery)) {
    $res = array("res" => "success");
} else {
    $res = array("res" => "failed", "error" => $conn->error);
}

echo json_encode($res);
?>
