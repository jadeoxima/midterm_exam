<?php 
 include("../../conn.php");

 if (isset($_POST['id'])) {
    $id=$_POST['id'];

    $query=mysqli_query($conn,"select * from program_tbl where cou_id='$id' ");
    while ($row=mysqli_fetch_array($query)) {
        $id=$row['id'];
        $program=$row['program'];
        echo "<option value'$id'>$program</option>"
    }
}
?>