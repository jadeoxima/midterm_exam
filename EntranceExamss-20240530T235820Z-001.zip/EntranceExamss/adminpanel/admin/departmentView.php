<?php 
session_start();

if(!isset($_SESSION['admin']['adminnakalogin']) == true) header("location:index.php");


 ?>
<?php include("../../conn.php"); ?>
<!-- MAO NI ANG HEADER -->
<?php include("includes/header.php"); ?>      

<!-- UI THEME DIRI -->
<?php include("includes/ui-theme.php"); ?>

<div class="app-main">
<!-- sidebar diri  -->
<?php include("includes/sidebar.php"); ?>

<?php 
  
  
  $id = isset($_GET['id']) ? $_GET['id'] : '';
 
  $selCourse = $conn->query("SELECT * FROM course_tbl WHERE cou_id='$id' ")->fetch(PDO::FETCH_ASSOC);

 ?>

<link rel="stylesheet" type="text/css" href="css/mycss.css">
<div class="app-main__outer">
        <div class="app-main__inner">
            <div class="app-page-title">
                <div class="page-title-wrapper">
                    <div class="page-title-heading">
                    <legend><i class="facebox-header"><i class="edit large icon"></i>&nbsp;View Department Name ( <?php echo strtoupper($selCourse['cou_name']); ?> )</i></legend>
                </div>
            </div>        
         
            <div class="col-md-12">
                <div class="main-card mb-3 card">
                    <div class="card-header">Student List</div>
                    <div class="float-right" align="center">
                    <a href="query/export.php?exmne_course=<?php echo $id; ?>" class="btn btn-info"><i class="fa fa-download"></i> Export to Excel</a>
                    </div>
               
                    <div class="table-responsive">
                        <table class="align-middle mb-0 table table-borderless table-striped table-hover" id="tableList">
                            <thead>
                            <tr>
                                
                                <th>Fullname</th>
                                <th>OR Number</th>
                                <th>Program</th>
                                <th>Status</th>

                            </tr>
                            </thead>
                            <tbody>
                              <?php 
                             

                               $selExmne = $conn->query("SELECT * FROM examinee_tbl WHERE exmne_course = '$id'");
                                if($selExmne->rowCount() > 0)
                                {
                                    while ($selExmneRow = $selExmne->fetch(PDO::FETCH_ASSOC)) { ?>
                                        <tr>
                                    
                                           <td><?php echo $selExmneRow['exmne_fullname']; ?></td>
                                           <td><?php echo $selExmneRow['exmne_ornumber']; ?></td>
                                           
                                           <td><?php echo $selExmneRow['exmne_program']; ?></td>
                                           <td><?php echo $selExmneRow['exmne_status']; ?></td>
                
                                        </tr>
                                    <?php }
                                }
                                else
                                { ?>
                                    <tr>
                                      <td colspan="2">
                                        <h3 class="p-3">No Results Found</h3>
                                      </td>
                                    </tr>
                                <?php }
                               ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>       
</div>