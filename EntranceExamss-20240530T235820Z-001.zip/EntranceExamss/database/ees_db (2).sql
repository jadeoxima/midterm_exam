-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2023 at 01:59 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ees_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_acc`
--

CREATE TABLE `admin_acc` (
  `admin_id` int(11) NOT NULL,
  `admin_user` varchar(1000) NOT NULL,
  `admin_pass` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin_acc`
--

INSERT INTO `admin_acc` (`admin_id`, `admin_user`, `admin_pass`) VALUES
(1, 'admin@username', 'admin@password');

-- --------------------------------------------------------

--
-- Table structure for table `course_tbl`
--

CREATE TABLE `course_tbl` (
  `cou_id` int(11) NOT NULL,
  `cou_name` varchar(1000) NOT NULL,
  `cou_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `course_tbl`
--

INSERT INTO `course_tbl` (`cou_id`, `cou_name`, `cou_created`) VALUES
(78, 'COLLEGE OF ALLIED & MEDICAL SCIENCES', '2023-06-04 09:42:07'),
(79, 'COLLEGE OF INFORMATION TECHNOLOGY', '2023-06-04 09:37:44'),
(80, 'COLLEGE OF TEACHER EDUCATION', '2023-06-04 09:38:03'),
(81, 'COLLEGE OF BUSINESS EDUCATION', '2023-06-04 09:38:08'),
(84, 'COLLEGE OF ENGINEERING & ARCHITECTURE ', '2023-06-04 09:38:15'),
(94, 'COLLEGE OF MARITIME EDUCATION', '2023-07-12 01:26:07');

-- --------------------------------------------------------

--
-- Table structure for table `examinee_tbl`
--

CREATE TABLE `examinee_tbl` (
  `exmne_id` int(11) NOT NULL,
  `exmne_fullname` varchar(1000) NOT NULL,
  `exmne_age` varchar(1000) NOT NULL,
  `exmne_course` varchar(1000) NOT NULL,
  `exmne_ornumber` varchar(1000) NOT NULL,
  `exmne_gender` varchar(1000) NOT NULL,
  `exmne_date` varchar(1000) NOT NULL,
  `exmne_program` varchar(1000) NOT NULL,
  `exmne_email` varchar(1000) NOT NULL,
  `exmne_password` varchar(1000) NOT NULL,
  `exmne_status` varchar(1000) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `examinee_tbl`
--

INSERT INTO `examinee_tbl` (`exmne_id`, `exmne_fullname`, `exmne_age`, `exmne_course`, `exmne_ornumber`, `exmne_gender`, `exmne_date`, `exmne_program`, `exmne_email`, `exmne_password`, `exmne_status`) VALUES
(44, 'Abel, Airose P.', '22', '79', '123432123', 'female', '2023-06-21', 'Bachelor of Science in Information Technology', 'airose@gmail.com', '1234', 'active'),
(45, 'kim', '22', '78', '1234323', 'female', '2023-06-20', 'Bachelor of Science in Nursing', 'kim@gmail.com', '1234', 'active'),
(46, 'tata', '22', '79', '12345678765', 'male', '2023-07-04', 'Bachelor of Science in Information Technology', 'tata@gmail.com', '1234', 'active'),
(47, 'Junbert', '22', '79', '1234432', 'male', '2023-07-13', 'Bachelor of Science in Information Technology', 'junbert@gmail.com', '1234', 'active'),
(48, 'sdft', '12', '78', '12321', 'male', '2023-07-18', 'Bachelor of Science in Accounting Information Technology', 'villanueva@gmail.com', '1234', 'active'),
(49, 'ljlnlunnlnl', '44', '80', '6787656', 'male', '2023-07-20', 'Bachelor of Science in Hospitality Management', 'ybtbj@gmail.com', '1234', 'active'),
(53, 'jade oxima', '21', '79', '987654321', 'male', '2000-08-23', 'Diploma in Information Technology', 'jade@gmail.com', 'jade123', 'active'),
(54, 'kahit sino', '21', '84', '87654329', 'female', '2000-09-12', 'Bachelor of Science in Civil Engineering', 'kahit@gmail.com', 'kahit123', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `exam_answers`
--

CREATE TABLE `exam_answers` (
  `exans_id` int(11) NOT NULL,
  `axmne_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `quest_id` int(11) NOT NULL,
  `exans_answer` varchar(1000) NOT NULL,
  `exans_status` varchar(1000) NOT NULL DEFAULT 'new',
  `exans_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `exam_answers`
--

INSERT INTO `exam_answers` (`exans_id`, `axmne_id`, `exam_id`, `quest_id`, `exans_answer`, `exans_status`, `exans_created`) VALUES
(1212, 46, 35, 147, '4', 'new', '2023-07-19 10:06:33'),
(1213, 46, 35, 146, 'West', 'new', '2023-07-19 10:06:34'),
(1214, 46, 34, 148, '7', 'new', '2023-07-19 10:06:53'),
(1215, 46, 34, 149, '10', 'new', '2023-07-19 10:06:53');

-- --------------------------------------------------------

--
-- Table structure for table `exam_attempt`
--

CREATE TABLE `exam_attempt` (
  `examat_id` int(11) NOT NULL,
  `exmne_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `examat_status` varchar(1000) NOT NULL DEFAULT 'used',
  `exam_created` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `exam_attempt`
--

INSERT INTO `exam_attempt` (`examat_id`, `exmne_id`, `exam_id`, `examat_status`, `exam_created`) VALUES
(94, 46, 35, 'used', '2023-07-19 10:06:34.090120'),
(95, 46, 34, 'used', '2023-07-19 10:06:53.882838');

-- --------------------------------------------------------

--
-- Table structure for table `exam_question_tbl`
--

CREATE TABLE `exam_question_tbl` (
  `eqt_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `exam_question` varchar(1000) NOT NULL,
  `exam_ch1` varchar(1000) NOT NULL,
  `exam_ch2` varchar(1000) NOT NULL,
  `exam_ch3` varchar(1000) NOT NULL,
  `exam_ch4` varchar(1000) NOT NULL,
  `exam_answer` varchar(1000) NOT NULL,
  `exam_status` varchar(1000) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `exam_question_tbl`
--

INSERT INTO `exam_question_tbl` (`eqt_id`, `exam_id`, `exam_question`, `exam_ch1`, `exam_ch2`, `exam_ch3`, `exam_ch4`, `exam_answer`, `exam_status`) VALUES
(146, 35, 'One morning after sunrise, Suresh was standing facing a pole. The shadow of the pole fell exactly to his right. To which direction was he facing?', 'East', 'South', 'West', ' Data is inadequate', 'East', 'active'),
(147, 35, 'All the faces of cubes are painted with red colour. The cubes is cut into 64 equal small cubes. How many small cubes have only one face coloured ?', '4', '8', '16', '24', '24', 'active'),
(148, 34, 'What is the next prime number after 5?', '6', '7', '9', '11', '7', 'active'),
(149, 34, 'Find the missing terms in multiple of 3: 3, 6, 9, __, 15', '10', '11', '12', '13', '12', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `exam_tbl`
--

CREATE TABLE `exam_tbl` (
  `ex_id` int(11) NOT NULL,
  `cou_id` int(11) NOT NULL,
  `ex_title` varchar(1000) NOT NULL,
  `ex_time_limit` varchar(1000) NOT NULL,
  `ex_questlimit_display` int(11) NOT NULL,
  `ex_description` varchar(1000) NOT NULL,
  `ex_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `exam_tbl`
--

INSERT INTO `exam_tbl` (`ex_id`, `cou_id`, `ex_title`, `ex_time_limit`, `ex_questlimit_display`, `ex_description`, `ex_created`) VALUES
(25, 79, 'English (Language Usage)', '15', 40, 'Entrance Exam', '2023-07-19 02:28:09'),
(29, 78, 'English (Spelling)', '10', 40, 'Entrance Exam', '2023-07-19 02:28:47'),
(33, 0, 'Science (Mechanical Reasoning)', '25', 60, 'Entrance Exam', '2023-07-19 02:27:49'),
(34, 0, 'Math (Numerical Reasoning)', '30', 40, 'Entrance Exam', '2023-07-19 02:27:37'),
(35, 0, 'English (Verbal Reasoning)', '25', 40, 'Entrance Exam', '2023-07-19 02:27:26');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks_tbl`
--

CREATE TABLE `feedbacks_tbl` (
  `fb_id` int(11) NOT NULL,
  `exmne_id` int(11) NOT NULL,
  `fb_exmne_as` varchar(1000) NOT NULL,
  `fb_feedbacks` varchar(1000) NOT NULL,
  `fb_date` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `feedbacks_tbl`
--

INSERT INTO `feedbacks_tbl` (`fb_id`, `exmne_id`, `fb_exmne_as`, `fb_feedbacks`, `fb_date`) VALUES
(11, 35, 'Junbert Villanueva ', 'Nice Work!', 'May 31, 2023'),
(12, 36, 'Airose Abel', 'hahahaahablanwrfaer', 'May 31, 2023'),
(13, 42, 'Anonymous', 'fhjhmnbvxjnf', 'June 19, 2023'),
(14, 44, 'Anonymous', 'nice!', 'June 22, 2023');

-- --------------------------------------------------------

--
-- Table structure for table `program_tbl`
--

CREATE TABLE `program_tbl` (
  `id` int(255) NOT NULL,
  `cou_id` int(255) NOT NULL,
  `program` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `program_tbl`
--

INSERT INTO `program_tbl` (`id`, `cou_id`, `program`) VALUES
(1, 84, 'Bachelor of Science in Architecture'),
(2, 84, 'Bachelor of Science in Civil Engineering'),
(3, 84, 'Bachelor of Science in Electrical Engineering'),
(4, 84, 'Bachelor of Science in Electronics Engineering'),
(5, 84, 'Bachelor of Science in Mechanical Engineering'),
(6, 78, 'Bachelor of Science in Nursing'),
(7, 78, 'Bachelor of Science in Radiologic Technology'),
(8, 78, 'Bachelor of Science in Midwifery\r\n'),
(9, 81, 'Bachelor of Science in Accountancy '),
(10, 81, 'Bachelor of Science in Hospitality Management'),
(11, 81, 'Bachelor of Science in Business Administration\r\n(Major in Marketing Management)\r\n'),
(12, 81, 'Bachelor of Science in Business Administration\r\n(Major in Human Resources Management)'),
(13, 81, 'Bachelor of Science in Business Administration\r\n(Major in Financial Management)'),
(14, 80, 'Bachelor of Elementary Education'),
(15, 80, 'Bachelor of Secondary Education (Major in Science)'),
(16, 80, 'Bachelor of Secondary Education (Major in Mathematics)'),
(17, 79, 'Bachelor of Science in Information Technology'),
(18, 84, 'Diploma in Construction Engineering Technology'),
(19, 84, 'Diploma in Electrical Engineering Technology'),
(20, 84, 'Diploma in Mechanical Engineering Technology'),
(21, 84, 'Diploma in Electronics Engineering Technology'),
(22, 79, 'Diploma in Information Technology'),
(23, 94, 'Bachelor of Science in Maritime Transportation '),
(24, 81, 'Bachelor of Science in Accounting Information Technology');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_acc`
--
ALTER TABLE `admin_acc`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `course_tbl`
--
ALTER TABLE `course_tbl`
  ADD PRIMARY KEY (`cou_id`);

--
-- Indexes for table `examinee_tbl`
--
ALTER TABLE `examinee_tbl`
  ADD PRIMARY KEY (`exmne_id`);

--
-- Indexes for table `exam_answers`
--
ALTER TABLE `exam_answers`
  ADD PRIMARY KEY (`exans_id`);

--
-- Indexes for table `exam_attempt`
--
ALTER TABLE `exam_attempt`
  ADD PRIMARY KEY (`examat_id`);

--
-- Indexes for table `exam_question_tbl`
--
ALTER TABLE `exam_question_tbl`
  ADD PRIMARY KEY (`eqt_id`);

--
-- Indexes for table `exam_tbl`
--
ALTER TABLE `exam_tbl`
  ADD PRIMARY KEY (`ex_id`);

--
-- Indexes for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  ADD PRIMARY KEY (`fb_id`);

--
-- Indexes for table `program_tbl`
--
ALTER TABLE `program_tbl`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cou_id` (`cou_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_acc`
--
ALTER TABLE `admin_acc`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course_tbl`
--
ALTER TABLE `course_tbl`
  MODIFY `cou_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `examinee_tbl`
--
ALTER TABLE `examinee_tbl`
  MODIFY `exmne_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `exam_answers`
--
ALTER TABLE `exam_answers`
  MODIFY `exans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1216;

--
-- AUTO_INCREMENT for table `exam_attempt`
--
ALTER TABLE `exam_attempt`
  MODIFY `examat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `exam_question_tbl`
--
ALTER TABLE `exam_question_tbl`
  MODIFY `eqt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT for table `exam_tbl`
--
ALTER TABLE `exam_tbl`
  MODIFY `ex_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  MODIFY `fb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `program_tbl`
--
ALTER TABLE `program_tbl`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `program_tbl`
--
ALTER TABLE `program_tbl`
  ADD CONSTRAINT `program_tbl_ibfk_1` FOREIGN KEY (`cou_id`) REFERENCES `course_tbl` (`cou_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
