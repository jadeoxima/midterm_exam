-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2023 at 12:35 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ees_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_acc`
--

CREATE TABLE `admin_acc` (
  `admin_id` int(11) NOT NULL,
  `admin_user` varchar(1000) NOT NULL,
  `admin_pass` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin_acc`
--

INSERT INTO `admin_acc` (`admin_id`, `admin_user`, `admin_pass`) VALUES
(1, 'admin@username', 'admin@password');

-- --------------------------------------------------------

--
-- Table structure for table `course_tbl`
--

CREATE TABLE `course_tbl` (
  `cou_id` int(11) NOT NULL,
  `cou_name` varchar(1000) NOT NULL,
  `cou_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `course_tbl`
--

INSERT INTO `course_tbl` (`cou_id`, `cou_name`, `cou_created`) VALUES
(78, 'COLLEGE OF ALLIED & MEDICAL SCIENCES', '2023-06-04 09:42:07'),
(79, 'COLLEGE OF INFORMATION TECHNOLOGY', '2023-06-04 09:37:44'),
(80, 'COLLEGE OF TEACHER EDUCATION', '2023-06-04 09:38:03'),
(81, 'COLLEGE OF BUSINESS EDUCATION', '2023-06-04 09:38:08'),
(84, 'COLLEGE OF ENGINEERING & ARCHITECTURE ', '2023-06-04 09:38:15'),
(94, 'COLLEGE OF MARITIME EDUCATION', '2023-07-23 09:53:59');

-- --------------------------------------------------------

--
-- Table structure for table `examinee_tbl`
--

CREATE TABLE `examinee_tbl` (
  `exmne_id` int(11) NOT NULL,
  `exmne_fullname` varchar(1000) NOT NULL,
  `exmne_age` varchar(1000) NOT NULL,
  `exmne_course` varchar(1000) NOT NULL,
  `exmne_ornumber` varchar(1000) NOT NULL,
  `exmne_gender` varchar(1000) NOT NULL,
  `exmne_date` varchar(1000) NOT NULL,
  `exmne_program` varchar(1000) NOT NULL,
  `exmne_email` varchar(1000) NOT NULL,
  `exmne_password` varchar(1000) NOT NULL,
  `exmne_status` varchar(1000) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `examinee_tbl`
--

INSERT INTO `examinee_tbl` (`exmne_id`, `exmne_fullname`, `exmne_age`, `exmne_course`, `exmne_ornumber`, `exmne_gender`, `exmne_date`, `exmne_program`, `exmne_email`, `exmne_password`, `exmne_status`) VALUES
(57, 'Jun', '22', '81', '2345654321', 'male', '2023-07-15', 'Bachelor of Science in Business Administration (Major in Human Resources Management)', 'jun@gmail.com', '1234', 'active'),
(58, 'Junb', '21', '84', '123432', 'male', '2023-07-22', 'Bachelor of Science in Architecture', 'junb@gmail.com', '1234', 'active'),
(59, 'tata', '21', '80', '23323', 'male', '2023-07-22', 'Bachelor of Secondary Education (Major in Mathematics)', 'tata@gmail.com', '1234', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `exam_answers`
--

CREATE TABLE `exam_answers` (
  `exans_id` int(11) NOT NULL,
  `axmne_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `quest_id` int(11) NOT NULL,
  `exans_answer` varchar(1000) NOT NULL,
  `exans_status` varchar(1000) NOT NULL DEFAULT 'new',
  `exans_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `exam_answers`
--

INSERT INTO `exam_answers` (`exans_id`, `axmne_id`, `exam_id`, `quest_id`, `exans_answer`, `exans_status`, `exans_created`) VALUES
(1212, 46, 35, 147, '4', 'new', '2023-07-19 10:06:33'),
(1213, 46, 35, 146, 'West', 'new', '2023-07-19 10:06:34'),
(1214, 46, 34, 148, '7', 'new', '2023-07-19 10:06:53'),
(1215, 46, 34, 149, '10', 'new', '2023-07-19 10:06:53'),
(1216, 59, 35, 155, 'phoney ------ authentic', 'new', '2023-07-22 01:32:50'),
(1217, 59, 35, 161, 'charm ------ gag', 'new', '2023-07-22 01:32:50'),
(1218, 59, 35, 171, 'ditch ------ scoop ', 'new', '2023-07-22 01:32:50'),
(1219, 59, 35, 163, 'quartet ------ song', 'new', '2023-07-22 01:32:50'),
(1220, 59, 35, 178, 'industry ------ harvest', 'new', '2023-07-22 01:32:50'),
(1221, 59, 35, 164, 'sleep ------ wake', 'new', '2023-07-22 01:32:50'),
(1222, 59, 35, 168, 'car ------ passage ', 'new', '2023-07-22 01:32:50'),
(1223, 59, 35, 167, 'snake ------ nest', 'new', '2023-07-22 01:32:50'),
(1224, 59, 35, 175, 'fat ------ plentiful', 'new', '2023-07-22 01:32:50'),
(1225, 59, 35, 160, 'twirl ------ spin', 'new', '2023-07-22 01:32:50'),
(1226, 59, 35, 172, 'scribble ------ speak ', 'new', '2023-07-22 01:32:50'),
(1227, 59, 35, 166, 'invite ------ court ', 'new', '2023-07-22 01:32:50'),
(1228, 59, 35, 173, 'early ------ second', 'new', '2023-07-22 01:32:50'),
(1229, 59, 35, 159, 'shallow ------ ocean', 'new', '2023-07-22 01:32:50'),
(1230, 59, 35, 177, 'average ------ general ', 'new', '2023-07-22 01:32:51'),
(1231, 59, 35, 162, 'business ------ greeting ', 'new', '2023-07-22 01:32:51'),
(1232, 59, 35, 169, 'seed ------ rose ', 'new', '2023-07-22 01:32:51'),
(1233, 59, 35, 156, 'seldom ------ hardly', 'new', '2023-07-22 01:32:51'),
(1234, 59, 35, 158, 'finish ------ stop', 'new', '2023-07-22 01:32:51'),
(1235, 59, 35, 181, 'education ------ medicine ', 'new', '2023-07-22 01:32:51'),
(1236, 59, 35, 176, 'rest ------ thirst ', 'new', '2023-07-22 01:32:51'),
(1237, 59, 35, 179, 'abandon ------ isolate ', 'new', '2023-07-22 01:32:51'),
(1238, 59, 35, 170, 'challenge ------ ask ', 'new', '2023-07-22 01:32:51'),
(1239, 59, 35, 180, 'moment ------ time ', 'new', '2023-07-22 01:32:51'),
(1240, 59, 35, 165, 'retreat ------ backward', 'new', '2023-07-22 01:32:51'),
(1241, 59, 35, 174, 'glove ------ shoe', 'new', '2023-07-22 01:32:51'),
(1242, 57, 35, 177, 'average ------ general ', 'new', '2023-07-22 04:00:03'),
(1243, 57, 35, 179, 'separate ------ isolate ', 'new', '2023-07-22 04:00:03'),
(1244, 57, 35, 198, 'paragraph ------ message ', 'new', '2023-07-22 04:00:03'),
(1245, 57, 35, 170, 'answer ------ respond ', 'new', '2023-07-22 04:00:03'),
(1246, 57, 35, 194, 'answer ------ outline', 'new', '2023-07-22 04:00:03'),
(1247, 57, 35, 158, 'start ------ open', 'new', '2023-07-22 04:00:03'),
(1248, 57, 35, 160, 'twirl ------ spin', 'new', '2023-07-22 04:00:03'),
(1249, 57, 35, 171, 'ditch ------ scoop ', 'new', '2023-07-22 04:00:03'),
(1250, 57, 35, 182, 'swift ------ driver ', 'new', '2023-07-22 04:00:03'),
(1251, 57, 35, 193, 'money ------ waste', 'new', '2023-07-22 04:00:03'),
(1252, 57, 35, 186, 'charming ------ curved', 'new', '2023-07-22 04:00:04'),
(1253, 57, 35, 159, 'water ------ well', 'new', '2023-07-22 04:00:04'),
(1254, 57, 35, 196, 'trade ------ take', 'new', '2023-07-22 04:00:04'),
(1255, 57, 35, 180, 'comma ------ end ', 'new', '2023-07-22 04:00:04'),
(1256, 57, 35, 184, 'ice ------ fire ', 'new', '2023-07-22 04:00:04'),
(1257, 57, 35, 191, 'kernel ------ rind', 'new', '2023-07-22 04:00:04'),
(1258, 57, 35, 176, 'rest ------ thirst ', 'new', '2023-07-22 04:00:04'),
(1259, 57, 35, 165, 'retreat ------ backward', 'new', '2023-07-22 04:00:04'),
(1260, 57, 35, 185, 'sky ------ railroad', 'new', '2023-07-22 04:00:04'),
(1261, 57, 35, 199, 'beach ------ wink', 'new', '2023-07-22 04:00:04'),
(1262, 57, 35, 168, 'corner ------ canal', 'new', '2023-07-22 04:00:04'),
(1263, 57, 35, 178, 'industry ------ harvest', 'new', '2023-07-22 04:00:04'),
(1264, 57, 35, 197, 'cloth ------ timber ', 'new', '2023-07-22 04:00:04'),
(1265, 57, 35, 162, 'signature ------ agreement ', 'new', '2023-07-22 04:00:04'),
(1266, 57, 35, 166, 'invite ------ court ', 'new', '2023-07-22 04:00:04'),
(1267, 57, 35, 172, 'ewcrvr', 'new', '2023-07-22 04:00:04'),
(1268, 57, 35, 167, 'snake ------ nest', 'new', '2023-07-22 04:00:04'),
(1269, 57, 35, 192, 'knit ------ loom ', 'new', '2023-07-22 04:00:04'),
(1270, 57, 35, 195, 'bird ------ animal', 'new', '2023-07-22 04:00:04'),
(1271, 57, 35, 173, 'early ------ second', 'new', '2023-07-22 04:00:05'),
(1272, 57, 35, 169, 'maple ------ petal ', 'new', '2023-07-22 04:00:05'),
(1273, 57, 35, 156, 'seldom ------ hardly', 'new', '2023-07-22 04:00:05'),
(1274, 57, 35, 175, 'fat ------ plentiful', 'new', '2023-07-22 04:00:05'),
(1275, 57, 35, 163, 'quarter ------ two', 'new', '2023-07-22 04:00:05'),
(1276, 57, 35, 174, 'glove ------ shoe', 'new', '2023-07-22 04:00:05'),
(1277, 57, 35, 161, 'trick ------ comedian', 'new', '2023-07-22 04:00:05'),
(1278, 57, 35, 187, 'candidate ------ employment', 'new', '2023-07-22 04:00:05'),
(1279, 57, 35, 181, 'teacher ------ hospital', 'new', '2023-07-22 04:00:05'),
(1280, 57, 35, 155, 'fraud ------ phoney', 'new', '2023-07-22 04:00:05'),
(1281, 57, 35, 164, 'dream ------ sleep', 'new', '2023-07-22 04:00:05');

-- --------------------------------------------------------

--
-- Table structure for table `exam_attempt`
--

CREATE TABLE `exam_attempt` (
  `examat_id` int(11) NOT NULL,
  `exmne_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `examat_status` varchar(1000) NOT NULL DEFAULT 'used',
  `exam_created` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `exam_attempt`
--

INSERT INTO `exam_attempt` (`examat_id`, `exmne_id`, `exam_id`, `examat_status`, `exam_created`) VALUES
(94, 46, 35, 'used', '2023-07-19 10:06:34.090120'),
(95, 46, 34, 'used', '2023-07-19 10:06:53.882838'),
(96, 59, 35, 'used', '2023-07-22 01:32:51.738276'),
(97, 57, 35, 'used', '2023-07-22 04:00:05.558396');

-- --------------------------------------------------------

--
-- Table structure for table `exam_question_tbl`
--

CREATE TABLE `exam_question_tbl` (
  `eqt_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `exam_question` varchar(1000) NOT NULL,
  `exam_ch1` varchar(1000) NOT NULL,
  `exam_ch2` varchar(1000) NOT NULL,
  `exam_ch3` varchar(1000) NOT NULL,
  `exam_ch4` varchar(1000) NOT NULL,
  `exam_ch5` varchar(255) NOT NULL,
  `exam_answer` varchar(1000) NOT NULL,
  `exam_status` varchar(1000) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `exam_question_tbl`
--

INSERT INTO `exam_question_tbl` (`eqt_id`, `exam_id`, `exam_question`, `exam_ch1`, `exam_ch2`, `exam_ch3`, `exam_ch4`, `exam_ch5`, `exam_answer`, `exam_status`) VALUES
(155, 35, '1. . . . . . . is to fake as genuine is to . . . . . . ', 'phoney ------ authentic', 'real ------ true', 'mask ------ real', 'authentic ------ sincere', 'fraud ------ phoney', 'phoney ------ authentic', 'active'),
(156, 35, '2. . . . . . . is to often as rarely is to . . . . . . ', 'seldom ------ hardly', 'always ------ sometimes', 'frequently ------ seldom', 'frequently ------ always', 'occasionally ------ never', 'frequently ------ seldom', 'active'),
(158, 35, '3. . . . . . . is to begin as close is to . . . . . . ', 'finish ------ stop', 'finish ------ near', 'end ------ open', 'stop ------ go', 'start ------ open', 'end ------ open', 'active'),
(159, 35, '4. . . . . . . is to creek as deep is to . . . . . . ', 'shallow ------ ocean', 'water ------ well', 'winding ------ well', 'brook ------ ocean', 'shallow ------ bottomless', 'shallow ------ ocean', 'active'),
(160, 35, '5. . . . . . . is to top as roll is to . . . . . . ', 'spin ------ round', 'twirl ------ spin', 'spin ------ ball ', 'toy ------ ball', 'toy ------ ball', 'spin ------ ball ', 'active'),
(161, 35, '6. . . . . . . is to magician as joke is to . . . . . . ', 'charm ------ gag', 'trick ------ humor', 'wizard ------ comedian', 'charm ------ laughter', 'trick ------ comedian', 'trick ------ comedian', 'active'),
(162, 35, '7. . . . . . . is to contract as handshake is to . . . . . . ', 'signature ------ gesture', 'business ------ greeting ', 'signature ------ agreement ', 'business ------ gesture', 'treaty ------ friendship ', 'signature ------ agreement ', 'active'),
(163, 35, '8. . . . . . . is to four as duet is to . . . . . . ', 'quartet ------ song', 'quartet ------ two ', 'quarter ------ two', 'two ------ one', 'number ------ song', 'quartet ------ two ', 'active'),
(164, 35, '9. . . . . . . is to slumber as rouse is to . . . . . . ', 'dream ------ wake', 'sleep ------ wake', 'nap ------ doze', 'dream ------ sleep', 'wake ------ stil', 'sleep ------ wake', 'active'),
(165, 35, '10. . . . . . . is to retract as forward is to . . . . . . ', 'retreat ------ backward', 'reject ------ reverse', 'extend ------ advance', 'extend ------ backward', 'enlarge ------ advance', 'extend ------ backward', 'active'),
(166, 35, '11. . . . . . . is to party as summon is to . . . . . . ', 'invite ------ court ', 'attend ------ order ', 'gather ------ jury', 'attend ------ ticket ', 'celebrate ------ trial', 'invite ------ court ', 'active'),
(167, 35, '12. . . . . . . is to bite as wasp is to . . . . . . ', 'snake ------ nest', 'spider ------ sting', 'dog ------ insect', 'bark ------ sting', 'spider ------ insect', 'spider ------ sting', 'active'),
(168, 35, '13. . . . . . . is to street as corridor is to . . . . . . ', 'drive ------ lane', 'car ------ passage ', 'corner ------ canal', 'pedestrian ------ house', 'avenue ------ hallway', 'avenue ------ hallway', 'active'),
(169, 35, '14. . . . . . . is to tree as bud is to . . . . . . ', 'seed ------ rose ', 'sapling ------ flower ', 'maple ------ petal ', 'seed ------ petal ', 'forest ------ bouquet', 'sapling ------ flower ', 'active'),
(170, 35, '15. . . . . . . is to question as reply is to . . . . . . ', 'answer ------ respond ', 'challenge ------ ask ', 'quiz ------ ask ', 'query ------ answer', 'inquire ------ challenge', 'query ------ answer', 'active'),
(171, 35, '16. . . . . . . is to dig as spoon is to . . . . . .', 'ditch ------ scoop ', 'shovel ------ soup ', 'ditch ------ knife ', 'shovel ------ scoop ', 'dirt ------ ladle', 'shovel ------ scoop ', 'active'),
(172, 35, '17. . . . . . . is to write as mumble is to . . . . . . ', 'read ------ listen', 'print ------ whisper', 'print ------ hear', 'scribble ------ listen', 'scribble ------ speak', 'scribble ------ speak', 'active'),
(173, 35, '18. . . . . . . is to late as first is to . . . . . .', 'early ------ second', 'last ------ second', 'slow ------ fast ', 'early ------ last ', 'tardy ------ last', 'early ------ last ', 'active'),
(174, 35, '19. . . . . . . is to hand as sock is to . . . . . . ', 'glove ------ shoe', 'glove ------ foot ', 'ring ------ toe ', 'finger ------ foot ', 'fist ------ punch', 'glove ------ foot ', 'active'),
(175, 35, '20. . . . . . . is to thin as abundant is to . . . . . . ', 'fat ------ plentiful', 'skinny ------ scare ', 'diet ------ feast ', 'fat ------ skinny', 'thick ------ sparse', 'thick ------ sparse', 'active'),
(176, 35, '21. . . . . . . is to fatigue as drink is to . . . . . . ', 'rest ------ thirst ', 'rest ------ water ', 'strength ------ water', 'sleep ------ food ', 'weariness ------ thirst', 'rest ------ thirst ', 'active'),
(177, 35, '22. . . . . . . is to ordinary as special is to . . . . . . . ', 'average ------ general ', 'common ------ unusual ', 'unfamiliar ------ inferior', 'unusual ------- rare ', 'odd ------ peculiar', 'common ------ unusual ', 'active'),
(178, 35, '23. . . . . . . . is to product as farm is to . . . . . . ', 'industry ------ harvest', 'manufacture ------ grow', 'laborer ------ crop ', 'industry ------ field', 'factory ------ crop ', 'factory ------ crop ', 'active'),
(179, 35, '24. . . . . . . is to accompany as dessert is to . . . . . . ', 'abandon ------ isolate ', 'escort ------ rescue', 'separate ------ isolate ', 'join ------ abandon', 'escort ------ join', 'join ------ abandon', 'active'),
(180, 35, '25. . . . . . . is to pause as period is to . . . . . . .', 'moment ------ time ', 'conversation ------ time', 'comma ------ end ', 'recess ------ end ', 'conversation ------ sentence ', 'comma ------ end ', 'active'),
(181, 35, '26. . . . . . . is to school as doctor is to . . . . . . ', 'education ------ medicine ', 'scholar ------ physician', 'lesson ------ illness', 'education ------ hospital', 'teacher ------ hospital', 'teacher ------ hospital', 'active'),
(182, 35, '27. . . . . . . is to fleet as truck is to . . . . . . ', 'swift ------ driver ', 'commander ------- highway', 'ship ------ caravan', 'commander ------ driver', 'ship ------ vehicle', 'ship ------ caravan', 'active'),
(184, 35, '28. . . . . . . is to cold as warm is to . . . . . . ', 'ice ------ fire ', 'hot ------ cool ', 'frozen ------ heat ', 'ice ------ hot ', 'friendly ------ tender', 'hot ------ cool ', 'active'),
(185, 35, '29. . . . . . . is to plane as engineer is to . . . . . . ', 'jet ------ train ', 'pilot ------ conductor', 'pilot ------ train ', 'airport ------ railroad', 'sky ------ railroad', 'pilot ------ train ', 'active'),
(186, 35, '30. . . . . . . is to graceful as crooked is to . . . . . .', 'charming ------ curved', 'clumsy ------ bent', 'awkward ------ straight ', 'clumsy ------ dishonest', 'beautiful ------ straight ', 'awkward ------ straight ', 'active'),
(187, 35, '31. . . . . . . is to election as applicant is to . . . . . .', 'vote ------ interview', 'voter ------ candidate', 'campaign ------ employment', 'candidate ------ employment', 'voter ------ business', 'candidate ------ employment', 'active'),
(191, 35, '32. . . . . . . is to corn as peel is to . . . . . . ', 'kernel ------ rind', 'husk ------ orange', 'vegetable ------ fruit ', 'husk ------ rind', 'stalk ------ skin', 'husk ------ orange', 'active'),
(192, 35, '33. . . . . . . is to sweater as weave is to . . . . . . ', 'knit ------ loom ', 'knit ------ basket ', 'jacket ------ rug', 'wool ------ yarn', 'jacket ------ loom', 'knit ------ basket ', 'active'),
(193, 35, '34. . . . . . . is to poverty as surplus is to . . . . . . ', 'money ------ waste', 'wealth ------ excess', 'pauper ------ shortage', 'save ------ waste', 'wealth ------ shortage', 'wealth ------ shortage', 'active'),
(194, 35, '35. . . . . . . is to solve as plot is to . . . . . . .', 'problem ------ scheme', 'puzzle ------ maneuver ', 'answer ------ outline', 'mystery ------ unravel', 'puzzle ------ story', 'puzzle ------ story', 'active'),
(195, 35, '36. . . . . . . is to robin as fur is to . . . . . . ', 'bird ------ animal', 'nest ------ pelt ', 'feather ------ coat ', 'feather ------ fox', 'wing ------ pelt', 'feather ------ fox', 'active'),
(196, 35, '37. . . . . . . is to buy as choose is to . . . . . . ', 'sell ------ pick ', 'trade ------ take', 'purchase ------ select', 'bargain ------ favor', 'sell ------ steal', 'purchase ------ select', 'active'),
(197, 35, '38. . . . . . . is to dye as wood is to . . . . . . ', 'cloth ------ timber ', 'tint ------ chop ', 'stain ------ ax', 'fabric ------ stain', 'color ------ paint', 'fabric ------ stain', 'active'),
(198, 35, '39. . . . . . . is to sentence as letter is to . . . . . . ', 'paragraph ------ message ', 'word ------ stamp', 'paragraph ------- alphabet', 'subject ------ message', 'phrase ------ word', 'phrase ------ word', 'active'),
(199, 35, '40. . . . . . . is to wave as eye is to . . . . . . ', 'hand ------ wink', 'hair ------ lash', 'ocean ----- storm', 'beach ------ wink', 'signal ------ see', 'hand ------ wink', 'active'),
(200, 29, '1. ', 'theme ', 'nomad', 'rescue', 'suffixs', '', 'suffixs', 'active'),
(201, 29, '2. ', 'anonymous ', 'triumphant', 'discusted', 'rhinoceros', '', 'discusted', 'active'),
(202, 29, '3.', 'glimse', 'thrifty', 'neutral', 'logic', '', 'glimse', 'active'),
(203, 29, '4. ', 'frugal', 'remidy', 'ballad', 'avenue', '', 'remidy', 'active'),
(204, 29, '5. ', 'symmetry', 'resturant', 'eavesdrop', 'pesticide', '', 'resturant', 'active'),
(205, 29, '6. ', 'lepard', 'fossil', 'vertical', 'afford', '', 'lepard', 'active'),
(207, 29, '7. ', 'histerical', 'technician', 'immobile', 'synthetic', '', 'histerical', 'active'),
(211, 29, '8.', 'epic', 'radius', 'omlet', 'stern', '', 'omlet', 'active'),
(212, 29, '9.', 'challenger', 'emphasize', 'bequeath', 'perscription', '', 'perscription', 'active'),
(213, 29, '10.', 'peculiar', 'reciept', 'episode', 'traction', '', 'reciept', 'active'),
(214, 29, '11.', 'accuse', 'fabric', 'immense', 'tackel', '', 'tackel', 'active'),
(215, 29, '12. ', 'achieve', 'pioneer', 'tourest', 'commend', '', 'tourest', 'active'),
(216, 29, '13.', 'visinity', 'obstacle', 'bachelor', 'civilian', '', 'visinity', 'active'),
(217, 29, '14.', 'sphere', 'occupant', 'reckage', 'faculty', '', 'reckage', 'active'),
(218, 29, '15.', 'explorer', 'hansome', 'municipal', 'coincide', '', 'hansome', 'active'),
(219, 29, '16. ', 'fanatic ', 'similiar', 'mosquito', 'lagoon', '', 'similiar', 'active'),
(220, 29, '17.', 'leutenant', 'captivity', 'sensory', 'dissatisfy', '', 'leutenant', 'active'),
(221, 29, '18. ', 'oblivion', 'metaphor', 'boundary', 'couragous', '', 'couragous', 'active'),
(222, 29, '19.', 'national', 'friction', 'hesitate', 'inforce', '', 'inforce', 'active'),
(223, 29, '20.', 'junction', 'responsable', 'transfusion', 'controversy', '', 'controversy', 'active'),
(224, 29, '21.', 'anniversary ', 'impersonate', 'fashion', 'inditment', '', 'inditment', 'active'),
(225, 29, '22. ', 'gesture', 'despose', 'moisture', 'exertion', '', 'despose', 'active'),
(226, 29, '23. ', 'rejoyce', 'acrobat', 'census', 'scholar', '', 'rejoyce', 'active'),
(227, 29, '24. ', 'brochure', 'moderation', 'livelyhood', 'hydraulic', '', 'livelyhood', 'active'),
(228, 29, '25. ', 'fortrees', 'departure', 'sincerly', 'quarrel', '', 'sincerly', 'active'),
(229, 29, '26. ', 'bombard', 'succeded', 'continent', 'gracious', '', 'succeded', 'active'),
(230, 29, '27. ', 'quicken', 'oppossed', 'demerit', 'gallery', '', 'oppossed', 'active'),
(231, 29, '28. ', 'preliminary', 'distingwish', 'consolation', 'trampoline', '', 'distingwish', 'active'),
(232, 29, '29. ', 'hickory ', 'volcano', 'allowable', 'mediocure', '', 'mediocure', 'active'),
(233, 29, '30. ', 'pharmacy', 'compell', 'utilize', 'trivial', '', 'compell', 'active'),
(234, 29, '31. ', 'antibiotic', 'investegate', 'camouflage ', 'preferable', '', 'investegate', 'active'),
(235, 29, '32.', 'filibuster', 'architecture', 'extravagant', 'representitive', '', 'representitive', 'active'),
(236, 29, '33. ', 'bankruptcy', 'linoleum', 'interfer', 'guidance', '', 'interfer', 'active'),
(237, 29, '34.', 'symphony', 'against', 'doubtfull', 'envious', '', 'doubtfull', 'active'),
(238, 29, '35.', 'employment', 'helicopter', 'defendent', 'altogether', '', 'defendent', 'active'),
(239, 29, '36.', 'appentice', 'moccasin', 'franchise', 'assumeing', '', 'assumeing', 'active'),
(240, 29, '37. ', 'courtious', 'accumulate', 'recreation', 'nuisance', '', 'courtious', 'active'),
(241, 29, '38. ', 'replica', 'quite', 'solem', 'memoir', '', 'solem', 'active'),
(242, 29, '39. ', 'auxiliary', 'reminisce', 'symbolize', 'majoraty', '', 'reminisce', 'active'),
(243, 29, '40. ', 'cousin', 'geyser', 'bargin', 'academy', '', 'bargin', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `exam_tbl`
--

CREATE TABLE `exam_tbl` (
  `ex_id` int(11) NOT NULL,
  `cou_id` int(11) NOT NULL,
  `ex_title` varchar(1000) NOT NULL,
  `ex_time_limit` varchar(1000) NOT NULL,
  `ex_questlimit_display` int(11) NOT NULL,
  `ex_description` varchar(1000) NOT NULL,
  `ex_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `exam_tbl`
--

INSERT INTO `exam_tbl` (`ex_id`, `cou_id`, `ex_title`, `ex_time_limit`, `ex_questlimit_display`, `ex_description`, `ex_created`) VALUES
(25, 79, 'English (Language Usage)', '15', 40, 'Entrance Exam', '2023-07-19 02:28:09'),
(29, 78, 'English (Spelling)', '10', 40, 'Entrance Exam', '2023-07-19 02:28:47'),
(33, 0, 'Science (Mechanical Reasoning)', '25', 60, 'Entrance Exam', '2023-07-19 02:27:49'),
(34, 0, 'Math (Numerical Reasoning)', '30', 40, 'Entrance Exam', '2023-07-19 02:27:37'),
(35, 0, 'English (Verbal Reasoning)', '25', 40, 'Entrance Exam', '2023-07-22 02:34:40');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks_tbl`
--

CREATE TABLE `feedbacks_tbl` (
  `fb_id` int(11) NOT NULL,
  `exmne_id` int(11) NOT NULL,
  `fb_exmne_as` varchar(1000) NOT NULL,
  `fb_feedbacks` varchar(1000) NOT NULL,
  `fb_date` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `feedbacks_tbl`
--

INSERT INTO `feedbacks_tbl` (`fb_id`, `exmne_id`, `fb_exmne_as`, `fb_feedbacks`, `fb_date`) VALUES
(11, 35, 'Junbert Villanueva ', 'Nice Work!', 'May 31, 2023'),
(12, 36, 'Airose Abel', 'hahahaahablanwrfaer', 'May 31, 2023'),
(13, 42, 'Anonymous', 'fhjhmnbvxjnf', 'June 19, 2023'),
(14, 44, 'Anonymous', 'nice!', 'June 22, 2023');

-- --------------------------------------------------------

--
-- Table structure for table `program_tbl`
--

CREATE TABLE `program_tbl` (
  `id` int(255) NOT NULL,
  `cou_id` int(255) NOT NULL,
  `program` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `program_tbl`
--

INSERT INTO `program_tbl` (`id`, `cou_id`, `program`) VALUES
(1, 84, 'Bachelor of Science in Architecture'),
(2, 84, 'Bachelor of Science in Civil Engineering'),
(3, 84, 'Bachelor of Science in Electrical Engineering'),
(4, 84, 'Bachelor of Science in Electronics Engineering'),
(5, 84, 'Bachelor of Science in Mechanical Engineering'),
(6, 78, 'Bachelor of Science in Nursing'),
(7, 78, 'Bachelor of Science in Radiologic Technology'),
(8, 78, 'Bachelor of Science in Midwifery\r\n'),
(9, 81, 'Bachelor of Science in Accountancy '),
(10, 81, 'Bachelor of Science in Hospitality Management'),
(11, 81, 'Bachelor of Science in Business Administration (Major in Marketing Management)'),
(12, 81, 'Bachelor of Science in Business Administration (Major in Human Resources Management)'),
(13, 81, 'Bachelor of Science in Business Administration (Major in Financial Management)'),
(14, 80, 'Bachelor of Elementary Education'),
(15, 80, 'Bachelor of Secondary Education (Major in Science)'),
(16, 80, 'Bachelor of Secondary Education (Major in Mathematics)'),
(17, 79, 'Bachelor of Science in Information Technology'),
(18, 84, 'Diploma in Construction Engineering Technology'),
(19, 84, 'Diploma in Electrical Engineering Technology'),
(20, 84, 'Diploma in Mechanical Engineering Technology'),
(21, 84, 'Diploma in Electronics Engineering Technology'),
(22, 79, 'Diploma in Information Technology'),
(23, 94, 'Bachelor of Science in Maritime Transportation '),
(24, 81, 'Bachelor of Science in Accounting Information Technology');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_acc`
--
ALTER TABLE `admin_acc`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `course_tbl`
--
ALTER TABLE `course_tbl`
  ADD PRIMARY KEY (`cou_id`);

--
-- Indexes for table `examinee_tbl`
--
ALTER TABLE `examinee_tbl`
  ADD PRIMARY KEY (`exmne_id`);

--
-- Indexes for table `exam_answers`
--
ALTER TABLE `exam_answers`
  ADD PRIMARY KEY (`exans_id`);

--
-- Indexes for table `exam_attempt`
--
ALTER TABLE `exam_attempt`
  ADD PRIMARY KEY (`examat_id`);

--
-- Indexes for table `exam_question_tbl`
--
ALTER TABLE `exam_question_tbl`
  ADD PRIMARY KEY (`eqt_id`);

--
-- Indexes for table `exam_tbl`
--
ALTER TABLE `exam_tbl`
  ADD PRIMARY KEY (`ex_id`);

--
-- Indexes for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  ADD PRIMARY KEY (`fb_id`);

--
-- Indexes for table `program_tbl`
--
ALTER TABLE `program_tbl`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cou_id` (`cou_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_acc`
--
ALTER TABLE `admin_acc`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course_tbl`
--
ALTER TABLE `course_tbl`
  MODIFY `cou_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `examinee_tbl`
--
ALTER TABLE `examinee_tbl`
  MODIFY `exmne_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `exam_answers`
--
ALTER TABLE `exam_answers`
  MODIFY `exans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1282;

--
-- AUTO_INCREMENT for table `exam_attempt`
--
ALTER TABLE `exam_attempt`
  MODIFY `examat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `exam_question_tbl`
--
ALTER TABLE `exam_question_tbl`
  MODIFY `eqt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=244;

--
-- AUTO_INCREMENT for table `exam_tbl`
--
ALTER TABLE `exam_tbl`
  MODIFY `ex_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  MODIFY `fb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `program_tbl`
--
ALTER TABLE `program_tbl`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `program_tbl`
--
ALTER TABLE `program_tbl`
  ADD CONSTRAINT `program_tbl_ibfk_1` FOREIGN KEY (`cou_id`) REFERENCES `course_tbl` (`cou_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
